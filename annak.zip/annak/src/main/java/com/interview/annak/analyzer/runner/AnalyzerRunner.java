package com.interview.annak.analyzer.runner;

public interface AnalyzerRunner {
    void execute();
}
