package com.interview.annak.dao;

public interface AnalyzerResult<T> {
    T getResult();
    void setResult(T t);
}
