package com.interview.annak.analyzer;

import com.interview.annak.dao.AnalyzerResult;

public interface Analyzer {
    AnalyzerResult analyzeData();
}
